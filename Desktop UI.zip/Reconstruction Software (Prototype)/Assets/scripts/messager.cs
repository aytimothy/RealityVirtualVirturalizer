﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class messager : MonoBehaviour
{
    //this script is used to send information between two screens

    //this variable will store the complete file name of the 
    public static string file_path;

    //coordinates varables collected on project screen
    public static int maxX;
    public static int maxY;
    public static int maxZ;
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
