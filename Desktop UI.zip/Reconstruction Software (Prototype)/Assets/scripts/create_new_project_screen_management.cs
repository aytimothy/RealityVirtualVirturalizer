﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class create_new_project_screen_management : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
    public void back_press()
    {
        SceneManager.LoadScene(2);
    }
}
